package poerelations;

public class POErelations 
{
    public static void main(String[] args) 
    {     	
        login object = new login();
	object.registerUser();
        object.loginUser();        
    }            
}
