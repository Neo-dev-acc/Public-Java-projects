
package poerelations;

import java.util.Scanner; 
import java.util.regex.Pattern; 
public class login 
{
   Scanner input = new Scanner(System.in);
   String firstName; 
	String lastName; 
	String registrationPassword; 
	String userName; 
	String loginPassword;
    
    public String registerUser()
    {
        //Getting user information for registration 
	System.out.println("Please enter your first name"); 
	firstName = input.nextLine(); 
	System.out.println("Please enter your last name"); 
	lastName = input.nextLine(); 
        
        //asking user for a username to be examined
        System.out.println("Enter a username of 5 characters or less including an underscore: "); 
            userName = input.nextLine();
	// While loop asking user to enter a valid username 
	while (true) 
	{ 
             
            // Checking if username meets requirements: 5 or fewer characters long and has an underscore 
            if (checkUsername(userName)) 
            { 
               System.out.println("Username successfully captured.");               
               break; // To stop the loop if the username is valid 
            } 
            else 
            { 
                // If username is not valid, ask the user to enter a valid username again 
                System.out.print("Username is not correctly formatted. Please ensure that your username contains an underscore "); 
                System.out.println("and is no more than 5 characters in length."); 
                userName = input.nextLine();
            } 
	} 
	// Loop until the user enters a valid password meeting complexity requirements in order to register
        System.out.println("Enter a password of at least 8 characters long including a capital letter, a number, and a special character: "); 
            registrationPassword = input.nextLine();
        while (true) 
        {
            if (checkPasswordComplexity(registrationPassword))                
            { 
                System.out.println("Password successfully captured");
                break; // To stop the loop if the password meets complexity requirements             
            } 
            else 
            { 
                System.out.print("Password is not correctly formatted. Please enter a password that is at least 8 characters long,"); 
                System.out.println("including a capital letter, a number, and a special character."); 
                registrationPassword = input.nextLine();            
            }            
        }                   
       return null;
    }
    
    public boolean loginUser()
    {
            System.out.println("Log in.");	
            System.out.print("Enter password to login: "); 
            loginPassword = input.nextLine();
        // A loop to ask the user for password that matches the password entered during registration
        while (true) 
        {                       
            //if-then-else statements to check if passwords match. 
            if (loginPassword.equals(registrationPassword)) 
            { 
            System.out.println("Welcome " + firstName + " " + lastName +"."); 
            returnLoginStatus();
            return false; // Stop the loop if the login password matches the registration password 
            } 
            else 
            { 
            System.out.println("Passwords do not match. Please try again.");
            loginPassword = input.nextLine();
            
            }
        }
    }
     //method checking the username entered if it meets requirements 
    public boolean checkUsername(String username) 
    { 
        return username.length() <= 5 && username.contains("_"); 
    }
    // method checking if password entered complements requirements 
    public static boolean checkPasswordComplexity(String password) 
    { 
        return password.length() >= 8 && 
	Pattern.compile("[A-Z]").matcher(password).find() && 
	Pattern.compile("[0-9]").matcher(password).find() && 
	Pattern.compile("[^a-zA-Z0-9]").matcher(password).find(); 
    }
    public static String returnLoginStatus() 
    {
       String successful = "successful login";
        System.out.println("successful login");
       return successful;                  
    }
}
